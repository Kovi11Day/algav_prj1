package com.algav.HybridesTries;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Ajout {
	
	/*public static HybridesTries ajoutString(String key,HybridesTries a, Value v ){
		if( a.isVide()){
			HybridesTries infVide = new HybridesTries();
			HybridesTries supVide = new HybridesTries();
			HybridesTries eqVide = new HybridesTries();
			if( key.length() == 1){
				
				Node n = new Node(key.charAt(0),v);
				return new HybridesTries(infVide, eqVide, supVide,n);
			}
			else{
				Node n = new Node(key.charAt(0),new Value());
				a.setEq(eqVide);
				return new HybridesTries( infVide,
						ajoutString(key.substring(1),a.getEq(),v), supVide,n);
				
			}		
			
		}
		
		else {
			char p = key.charAt(0);
			if(p < a.getRacine().getKey()) {
				return new HybridesTries(ajoutString(key, a.getInf(),
						v), a.getEq(), a.getSup(),a.getRacine());
			}
			
			if(p>a.getRacine().getKey()){
				return new HybridesTries(a.getInf(), a.getEq(),
						ajoutString(key,a.getSup(),v), a.getRacine());
			}
			if( key.length() > 1){
				return new HybridesTries(a.getInf(),ajoutString(key.substring(1),
					a.getEq(),v),a.getSup(),a.getRacine());
			}
			a.getRacine().setValue(v);
			return a;
			
		}
	}*/
	
	public static HybridesTries ajoutString(String key,HybridesTries a){
		if( a.isVide()){
			HybridesTries infVide = new HybridesTries();
			HybridesTries supVide = new HybridesTries();
			HybridesTries eqVide = new HybridesTries();
			if( key.length() == 1){
				
				Node n = new Node(key.charAt(0),new ValueNonVide());
				HybridesTries h = new HybridesTries(infVide, eqVide, supVide,n);
				return h;
			}
			else{
				Node n = new Node(key.charAt(0),new ValueVide());
				a.setEq(eqVide);
				return new HybridesTries( infVide,
						ajoutString(key.substring(1),a.getEq()), supVide,n);
				
			}		
			
		}
		
		else {
			char p = key.charAt(0);
			if(p < a.getRacine().getKey()) {
				return new HybridesTries(ajoutString(key, a.getInf()),
						a.getEq(), a.getSup(),a.getRacine());
			}
			
			if(p>a.getRacine().getKey()){
				return new HybridesTries(a.getInf(), a.getEq(),
						ajoutString(key,a.getSup()), a.getRacine());
			}
			if( key.length() > 1){
				return new HybridesTries(a.getInf(),ajoutString(key.substring(1),
					a.getEq()),a.getSup(),a.getRacine());
			}
			if(a.getRacine().getValue() instanceof ValueVide){
				a.getRacine().setValue(new ValueNonVide());
			}
			return a;
			
		}
	}
	public static HybridesTries ajoutText(String s, HybridesTries h){
		HybridesTries newH = h;
		String[] splitArray = s.split(" ");
		for (int i = 0 ; i < splitArray.length; i++){
			newH = ajoutString(splitArray[i],newH);
		}
		
		return newH;
	}
	
	
	/*public static HybridesTries ajoutText(String s, HybridesTries h){
		HybridesTries newH = h;
		HashSet<String> hs = new HashSet<String>();
		String[] splitArray = s.split(" ");
		// utilise hashSet pour retirer les doublons 
		for (int i = 0; i < splitArray.length ; i++){
			hs.add(splitArray[i]);
		}
		String[] newSplitArray = new String[hs.size()];
		hs.toArray(newSplitArray);
		int addNbMots = newSplitArray.length;
		for (int i = 0 ; i < addNbMots; i++){
			newH = ajoutString(newSplitArray[i],newH,new Value(i));
	
		}
		newH.addNbMots(addNbMots);
		
		return newH;
	}*/
	
	public static boolean recherche (HybridesTries h, String mot){
		boolean existe = true;
		if( !h.isVide() ){
			char c = h.getRacine().getKey();
			if(c == mot.charAt(0)){
				if( mot.length() > 1) {
					if(h.getEq().isVide())
						return false;
					else
						existe &= true  && recherche(h.getEq(),mot.substring(1));
				}
				if(mot.length() == 1){
					if( h.getRacine().getValue() instanceof ValueVide){
						return false;
					}
					else
						return true;
				}
			}
					
			if(c > mot.charAt(0))
					existe &= recherche(h.getInf(),mot);
			if( c < mot.charAt(0))
					existe &= recherche(h.getSup(),mot);
				
		}
		else
			return false;
	return existe;
	}
	
	public static int comptageMots(HybridesTries h){
		int nbMots = 0;
		if(!h.isVide()){
			if( h.getRacine().getValue() instanceof ValueNonVide){
				nbMots+=1;
			}
			nbMots += comptageMots(h.getInf());
			nbMots += comptageMots(h.getEq());
			nbMots += comptageMots(h.getSup());
			
		}
		return nbMots;
	}
	
	public static ArrayList<String> liste(HybridesTries h){
		ArrayList<String> lesmots = new ArrayList<String>();
		listeMots(h,lesmots,"");
		return lesmots;
		
	}
	
	public static void listeMots(HybridesTries h,ArrayList<String> lesMots,
			String mot){
		String chars = mot;
		String chars2;
		if(!h.isVide()){
			
				listeMots(h.getInf(),lesMots,chars);
				chars2 = chars + h.getRacine().getKey();
				listeMots(h.getEq(),lesMots,chars2);
				//chars+=h.getRacine().getKey();
				if(h.getRacine().getValue() instanceof ValueNonVide){
					lesMots.add(chars2);
					}
						
				listeMots(h.getSup(), lesMots,chars);
						
			}		
		}
	//nb de pointer vers nill
	public static int nbTrieVide(HybridesTries h){
		int nb = 0;
		if(! h.isVide()){
			nb += nbTrieVide(h.getInf());
			nb += nbTrieVide(h.getEq());
			nb += nbTrieVide(h.getSup());
		}
		else{
		
			nb++;
		}
		return nb;
		
	}
	//compte la hauteur de la racine a la feuille
	public static int hauteur(HybridesTries h){
		int nb = 0 ;
		if(!h.isVide()){
			nb +=1+ Math.max( Math.max( hauteur(h.getInf()), hauteur(h.getEq()) ),
					hauteur(h.getSup()) );
		}
		if( h.isVide())
			return -1;
		
		return nb;
	}
	
	public static double profondeurMoyenne(HybridesTries h){
		double profM = ((double) nbNoeud(h))/nbFeuille(h);
		return profM;
	}
	public static int nbNoeud(HybridesTries h){
		int nb = 0;
		if(!h.isVide()){
			nb += nbNoeud(h.getInf());
			nb +=nbNoeud(h.getEq());
			nb += nbNoeud(h.getSup());
			nb +=1;
		}
			
		if(h.isVide()){
			return 0;
		}
	return nb;
		
	}	
	
	
	public static int nbFeuille(HybridesTries h){
		int nb = 0;
		if(h.isVide())
			return 0;
		if(h.getInf().isVide() && h.getEq().isVide() && h.getSup().isVide())
			return 1;
		
		nb += nbFeuille(h.getInf());
		nb += nbFeuille(h.getEq());
		nb += nbFeuille(h.getSup());
		return nb;
	}
	
	public static int prefixe(HybridesTries h , String mot){
		int nb = 0;
		char p = mot.charAt(0);
		if(! h.isVide()){
			if(h.getRacine().getKey() == p){
				if(mot.length() == 1){
					nb = comptageMots(h.getEq());
					// teste si mot est un mot dans h
					if(h.getRacine().getValue() instanceof ValueNonVide){
						 nb+=1;
					}
					return nb;
				}
				else{
					nb += prefixe(h.getEq(),mot.substring(1));
				}
			}
			if(p < h.getRacine().getKey()){
				nb +=prefixe(h.getInf(),mot);
			}
			if(p>h.getRacine().getKey()){
				nb +=prefixe(h.getSup(),mot);
			}
		}
		return nb;		
	}
	
	public static HybridesTries inserer(HybridesTries h, HybridesTries g){
		char c = h.getRacine().getKey();
		
		if( g.isVide()){
			return new HybridesTries(h.getInf(),h.getEq(),h.getSup(),h.getRacine());
			}
		
		if( c < g.getRacine().getKey()){
			return new HybridesTries(inserer(h,g.getInf()),g.getEq(),
					g.getSup(), g.getRacine());
		}
		if( c > g.getRacine().getKey()){
			return new HybridesTries(g.getInf(),g.getEq(),
					inserer(h,g.getSup()), g.getRacine());
		}
		return new HybridesTries(g.getInf(), inserer(h.getEq(),g.getEq()),
				g.getSup(),g.getRacine() );
	}
	
	public static HybridesTries supression(HybridesTries h, String mot){
		char p = mot.charAt(0);
		if(! h.isVide()){
			if(h.getRacine().getKey() < p){
				HybridesTries g = new HybridesTries(h.getInf(),h.getEq(),
						supression(h.getSup(),mot),h.getRacine());
				if(g.getEq().isVide()){
					
					HybridesTries nv = inserer(g.getInf(),g.getSup().getInf());
					return new HybridesTries(g.getSup().getInf(),
							g.getSup().getEq(),
							nv,
							g.getSup().getRacine());
					}
					
				}
				
			
			if(h.getRacine().getKey() > p){
				return new HybridesTries(supression(h.getInf(),mot), h.getEq(), 
						h.getSup(), h.getRacine());
			}
			
			if(h.getRacine().getKey() == p){
				if(mot.length() == 1){
					if(h.troisFilsVide()){
						return new HybridesTries();
						
					}
					if(!h.getEq().isVide()){
						Value vide = new ValueVide();
						h.getRacine().setValue(vide);
						return new HybridesTries(h.getInf(),h.getEq(),
								h.getSup(),h.getRacine());
					}
					return new HybridesTries(h.getSup().getInf(),
							h.getSup().getEq() ,
							inserer(h.getInf(),h.getSup().getInf()),
							h.getSup().getRacine());
				}
				HybridesTries g = new HybridesTries(h.getInf(),
						supression(h.getEq(),mot.substring(1)),
						h.getSup(),h.getRacine());
				if(g.troisFilsVide() || g.isVide()){
					return new HybridesTries();
				}
				if(g.getEq().isVide()){
					HybridesTries nv = inserer(g.getInf(),g.getSup().getInf());
					return new HybridesTries(g.getSup().getInf(),
							g.getSup().getEq(),
							nv,
							g.getSup().getRacine());
				}
				return new HybridesTries(g.getInf(),g.getEq(),g.getSup(),
						g.getRacine());
				
			}
		}
		return new HybridesTries();
		
	}
	
}
//https://algo.infoprepa.epita.fr//index.php/Epita:Algo:Cours:Info-Sup:Arbres_de_recherche
	
