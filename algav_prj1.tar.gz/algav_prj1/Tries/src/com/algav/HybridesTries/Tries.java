package com.algav.HybridesTries;

public interface Tries {

}
