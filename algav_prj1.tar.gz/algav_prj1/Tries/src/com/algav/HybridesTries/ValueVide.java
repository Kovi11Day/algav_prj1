package com.algav.HybridesTries;

public class ValueVide implements Value{
	
	public ValueVide(){
		
	}

	@Override
	public int getValeurValue() {
		
		return -1;
	}

}
