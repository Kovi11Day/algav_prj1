package com.algav.HybridesTries;

public class HybrideEmptyException extends HybrideException{
	
	public HybrideEmptyException(){
		super("Arbre vide");
	}
	

}
