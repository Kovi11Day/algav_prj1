package com.algav.HybridesTries;

public class HybrideException extends Exception{
	
	public HybrideException(String s){
		super(s);
	}

	

}
