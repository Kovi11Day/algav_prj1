package com.algav.HybridesTries;

public interface Value {
	public int getValeurValue();
	

}
