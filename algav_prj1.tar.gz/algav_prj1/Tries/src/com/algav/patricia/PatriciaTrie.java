package com.algav.patricia;

import com.algav.patricia.string.IPATString;

public class PatriciaTrie implements IPatriciaTrie{

	private IPATString[] node;
	
	public PatriciaTrie(IPATString mot){
	}
}
