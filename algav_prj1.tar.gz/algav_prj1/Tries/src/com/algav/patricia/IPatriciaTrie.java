package com.algav.patricia;

import com.algav.patricia.string.IPATString;

public interface IPatriciaTrie {
	
	
}
