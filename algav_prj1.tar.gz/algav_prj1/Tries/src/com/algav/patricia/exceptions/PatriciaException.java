package com.algav.patricia.exceptions;

public class PatriciaException extends Exception {

	public PatriciaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
