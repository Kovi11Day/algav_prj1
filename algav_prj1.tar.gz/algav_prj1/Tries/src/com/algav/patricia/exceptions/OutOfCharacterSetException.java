package com.algav.patricia.exceptions;

public class OutOfCharacterSetException extends PatriciaException{

	public OutOfCharacterSetException() {
		super("Out of Character Set");
	}

}
