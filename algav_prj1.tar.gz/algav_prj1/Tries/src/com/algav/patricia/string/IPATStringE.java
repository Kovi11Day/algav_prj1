package com.algav.patricia.string;

public interface IPATStringE {
	String getStr();
}
