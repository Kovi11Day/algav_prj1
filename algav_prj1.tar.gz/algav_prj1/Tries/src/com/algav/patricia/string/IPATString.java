package com.algav.patricia.string;

public interface IPATString {
	String getStr();
	IPATStringE endWord (IPATString str);
}
